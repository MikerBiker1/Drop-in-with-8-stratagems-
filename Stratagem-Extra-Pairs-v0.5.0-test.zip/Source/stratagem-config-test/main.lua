-- HD2-Addon: mods/custom/stratagem_link_test
-- Stratagem Extra Pairs v0.5.0 - configurable test - Miker and ChatGPT/Codex
-- Memory reader adapted from the supplied M6C addon / Dagger and Jump Pack probes.
if rawget(_G,'StratagemExtraPairs') then return end
assert(not rawget(_G,'StratagemChainTest') and not rawget(_G,'StratagemFourLinkTest') and not rawget(_G,'StratagemLinkTest'),'Disable the previous single-link test and restart')
local ffi_ok,ffi=pcall(require,'ffi')
local CHUNK = 262144
local MEM_COMMIT, MEM_PRIVATE = 0x1000, 0x20000
local PAGE_READONLY, PAGE_READWRITE = 0x02, 0x04
local function is_scannable_protection(p) return p==2 or p==4 or p==0x20 or p==0x40 end
local function build_api()
    -- Every mod shares one LuaJIT VM, so a cdef another mod already made wins. Declare
    -- one at a time and ignore redefinitions, take VirtualQuery's region as an opaque
    -- pointer so a differently-typed prior declaration still matches, and cast our own
    -- call to the typed signature.
    for _, declaration in ipairs({
        'void *GetCurrentProcess(void);',
        'uint64_t GetTickCount64(void);',
        'int WriteProcessMemory(void *process, void *address, const void *buffer, size_t size, size_t *written);',
        'int ReadProcessMemory(void *process, const void *address, void *buffer, size_t size, size_t *read);',
        'size_t VirtualQuery(const void *address, void *region, size_t size);',
        'int CreateDirectoryA(const char *path, void *security);',
        'uint32_t GetLastError(void);',
        'void *memchr(const void *s, int c, size_t n);',
        'int memcmp(const void *a, const void *b, size_t n);',
    }) do
        pcall(ffi.cdef, declaration)
    end
    -- Uniquely named so it can never collide with another mod's region struct.
    pcall(ffi.cdef, [[typedef struct {
        void *base; void *allocation_base; uint32_t allocation_protection;
        uint16_t partition; uint16_t reserved; size_t size;
        uint32_t state; uint32_t protection; uint32_t type;
    } JumpPackProbeRegion;]])

    local kernel = ffi.load('kernel32')
    local query = ffi.cast('size_t (*)(const void *, void *, size_t)', kernel.VirtualQuery)
    local process = kernel.GetCurrentProcess()
    local region = ffi.new('JumpPackProbeRegion[1]')
    local region_size = ffi.sizeof(region[0])
    local counter = ffi.new('size_t[1]')

    -- One scratch buffer for the whole session. Allocating a fresh one per chunk and
    -- then calling ffi.string on it to search turns every megabyte scanned into two
    -- megabytes of garbage -- and this LuaJIT VM is shared with every other mod, so
    -- that collection pressure is not ours alone to pay. Measured on LuaJIT 2.1:
    -- 118 MB/s and 2048 KB of garbage per MB, against 7599 MB/s and 0.2 KB per MB for
    -- the C search below.
    local scratch = ffi.new('uint8_t[?]', CHUNK)

    -- Needles are registered before scanning starts and all of them are looked for in
    -- the same pass over each chunk.
    local needles, longest = {}, 0

    -- memchr/memcmp are byte-exact, so this finds exactly what string.find found --
    -- including a signature at an odd alignment. If another mod declared them with
    -- incompatible types, fall back to the Lua search rather than failing outright.
    local memchr, memcmp
    local c_search = pcall(function()
        memchr, memcmp = ffi.C.memchr, ffi.C.memcmp
        local probe = ffi.new('uint8_t[4]', {1, 2, 3, 4})
        assert(memchr(probe, 3, 4) ~= nil and memcmp(probe, probe, 4) == 0)
    end)

    local self = {}
    local get_ticks = ffi.cast('uint64_t (*)(void)', kernel.GetTickCount64)
    function self.now_ms() return tonumber(get_ticks()) end
    self.c_search = c_search

    function self.add_needle(bytes)
        local entry = {text = bytes, len = #bytes, head = bytes:byte(1),
                       data = ffi.new('uint8_t[?]', #bytes)}
        ffi.copy(entry.data, bytes, #bytes)
        needles[#needles + 1] = entry
        if entry.len > longest then longest = entry.len end
        return #needles
    end

    -- Chunks must overlap by at least this much, or a needle straddling the boundary
    -- between two reads is seen by neither.
    function self.longest_needle() return longest end

    -- Pointer arguments are always cast: passing a bare Lua number raises
    -- "cannot convert number to const void *" and kills the whole scan.
    function self.read(address, size)
        if size <= 0 then return nil end
        local buffer = ffi.new('uint8_t[?]', size)
        if kernel.ReadProcessMemory(process, ffi.cast('const void *', address),
                                    buffer, size, counter) == 0 then return nil end
        if tonumber(counter[0]) ~= size then return nil end
        return ffi.string(buffer, size)
    end

    function self.write4(address, bytes)
        if #bytes ~= 4 then return false end
        local buffer = ffi.new('uint8_t[4]')
        ffi.copy(buffer, bytes, 4)
        counter[0] = 0
        return kernel.WriteProcessMemory(process, ffi.cast('void *', address), buffer, 4, counter) ~= 0 and tonumber(counter[0]) == 4
    end

    function self.query(address)
        if query(ffi.cast('const void *', address), region, region_size) ~= region_size then
            return nil
        end
        local base = tonumber(ffi.cast('uintptr_t', region[0].base))
        local size = tonumber(region[0].size)
        if not base or not size or size <= 0 then return nil end
        return {base = base, size = size, state = region[0].state,
                protection = region[0].protection, kind = region[0].type,
                -- VirtualQuery's allocation base: the VirtualAlloc that owns this
                -- region. The loader lays the data tables out relative to it, which
                -- is what turns the locate below into a comparison, not a sweep.
                allocation_base = tonumber(ffi.cast('uintptr_t', region[0].allocation_base))}
    end

    -- Read one chunk into the scratch buffer and report every signature hit in it.
    -- Returns false if the chunk could not be read at all.
    function self.scan(address, size, found)
        if size <= 0 or size > CHUNK then return false end
        if kernel.ReadProcessMemory(process, ffi.cast('const void *', address),
                                    scratch, size, counter) == 0 then return false end
        if tonumber(counter[0]) ~= size then return false end
        if c_search then
            for index = 1, #needles do
                local entry = needles[index]
                local cursor, remaining = scratch, size
                while remaining >= entry.len do
                    local hit = memchr(cursor, entry.head, remaining - entry.len + 1)
                    if hit == nil then break end
                    hit = ffi.cast('uint8_t *', hit)
                    local step = tonumber(hit - cursor)
                    if memcmp(hit, entry.data, entry.len) == 0 then
                        found(address + (size - remaining) + step, index)
                    end
                    remaining = remaining - step - 1
                    cursor = hit + 1
                end
            end
        else
            local blob = ffi.string(scratch, size)
            for index = 1, #needles do
                local entry = needles[index]
                local position = 1
                while true do
                    local hit = blob:find(entry.text, position, true)
                    if not hit then break end
                    found(address + hit - 1, index)
                    position = hit + 1
                end
            end
        end
        return true
    end

    function self.address_of(text)
        local ok, value = pcall(function()
            return tonumber(ffi.cast('uintptr_t', ffi.cast('const char *', text)))
        end)
        if ok then return value end
        return nil
    end

    function self.mkdir(path)
        return kernel.CreateDirectoryA(path, nil) ~= 0 or kernel.GetLastError() == 183
    end

    return self
end

local function fromhex(s)return (s:gsub('..',function(v)return string.char(tonumber(v,16))end))end
local catalog={
 ['AmmoBackpack']={name='AmmoBackpack',id=1907808218,code=fromhex('030000000400000003000000010000000100000003000000'),package=fromhex('ad50bd5ea7809951')},
 ['BallisticShield']={name='BallisticShield',id=3353508219,code=fromhex('030000000400000003000000030000000100000004000000'),package=fromhex('df15fff3f25b1afc')},
 ['Directional_Shield']={name='Directional_Shield',id=272480476,code=fromhex('030000000100000004000000020000000100000001000000'),package=fromhex('151c55874780fa93')},
 ['ShieldGeneratorPack']={name='ShieldGeneratorPack',id=3843705076,code=fromhex('030000000100000004000000020000000400000002000000'),package=fromhex('2ce4aa3c883ab447')},
 ['Jumppack']={name='Jumppack',id=1753436707,code=fromhex('0300000001000000010000000300000001000000'),package=fromhex('731ab8da1f58783e')},
 ['HoverPack']={name='HoverPack',id=73468749,code=fromhex('030000000100000001000000030000000400000002000000'),package=fromhex('fbbe7e3c7a6ffe1d')},
 ['DroneMG']={name='DroneMG',id=485866824,code=fromhex('030000000100000004000000010000000200000003000000'),package=fromhex('1987cbad0f266cbe')},
 ['Drone_Laser_Rifle']={name='Drone_Laser_Rifle',id=951988742,code=fromhex('030000000100000004000000010000000200000002000000'),package=fromhex('a0b5a11d3244cb32')},
 ['Drone_Gas']={name='Drone_Gas',id=5185868,code=fromhex('030000000100000004000000010000000200000001000000'),package=fromhex('0a380da04fcaf435')},
 ['Drone_Flamer']={name='Drone_Flamer',id=1125307795,code=fromhex('030000000100000004000000010000000400000004000000'),package=fromhex('9ab7f98b2728ec82')},
 ['PortableHellbomb']={name='PortableHellbomb',id=45875024,code=fromhex('0300000002000000010000000100000001000000'),package=fromhex('f43fa16c5d786d34')},
 ['WarpPack']={name='WarpPack',id=2185045091,code=fromhex('030000000400000002000000030000000400000002000000'),package=fromhex('684f505a4070f668')},
 ['Drone_Stun_Arc']={name='Drone_Stun_Arc',id=1692135420,code=fromhex('030000000100000004000000010000000200000004000000'),package=fromhex('a36c7fad5bb42ae6')},
 ['GrenadierBattlement']={name='GrenadierBattlement',id=2480128092,code=fromhex('0300000002000000030000000400000002000000'),package=fromhex('a2e705c484b44e9d')},
 ['ShieldGeneratorRelay']={name='ShieldGeneratorRelay',id=2281932031,code=fromhex('030000000300000004000000020000000400000002000000'),package=fromhex('61acb9c24ab30dfe')},
 ['HMG_Emplacement']={name='HMG_Emplacement',id=2919842659,code=fromhex('030000000100000004000000020000000200000004000000'),package=fromhex('f502c6c17604e868')},
 ['AntiPersonnalMine']={name='AntiPersonnalMine',id=12688472,code=fromhex('03000000040000000100000002000000'),package=fromhex('1700c7b2256494a4')},
 ['IncendiaryMines']={name='IncendiaryMines',id=2742141597,code=fromhex('03000000040000000400000003000000'),package=fromhex('6e907437fa975a33')},
 ['AntiTankMines']={name='AntiTankMines',id=2239174926,code=fromhex('03000000040000000100000001000000'),package=fromhex('1cf5dacdc74bce12')},
 ['GasMines']={name='GasMines',id=644090457,code=fromhex('03000000040000000400000002000000'),package=fromhex('b3f0d8477bdb8eef')},
 ['TurretTesla']={name='TurretTesla',id=2402590523,code=fromhex('030000000100000002000000010000000400000002000000'),package=fromhex('1b1244551ffbbf8a')},
 ['AntiTankEmplacement']={name='AntiTankEmplacement',id=762584056,code=fromhex('030000000100000004000000020000000200000002000000'),package=fromhex('03b495267f040f5a')},
 ['OrbitalPrecisionStrike']={name='OrbitalPrecisionStrike',id=3523620028,code=fromhex('020000000200000001000000'),package=fromhex('706df0605052aedb')},
 ['OrbitalGasStrike']={name='OrbitalGasStrike',id=3193297673,code=fromhex('02000000020000000300000002000000'),package=fromhex('406aa33767816963')},
 ['OrbitalAirburstStrike']={name='OrbitalAirburstStrike',id=1560416221,code=fromhex('020000000200000002000000'),package=fromhex('82a54255b24213f5')},
 ['OrbitalGatlingBarrage']={name='OrbitalGatlingBarrage',id=2084654169,code=fromhex('0200000003000000040000000100000001000000'),package=fromhex('18c6b3b031a0727d')},
 ['Orbital120mmHEBarrage']={name='Orbital120mmHEBarrage',id=1063322614,code=fromhex('020000000200000003000000040000000200000003000000'),package=fromhex('12017c6cf2cfb825')},
 ['OrbitalNapalmBarrage']={name='OrbitalNapalmBarrage',id=2902516083,code=fromhex('020000000200000003000000040000000200000001000000'),package=fromhex('5f4c330647dfce96')},
 ['Orbital380mmHEBarrage']={name='Orbital380mmHEBarrage',id=3108516875,code=fromhex('02000000030000000100000001000000040000000300000003000000'),package=fromhex('e2a1e40043f43efe')},
 ['OrbitalWalkingBarrage']={name='OrbitalWalkingBarrage',id=3279813377,code=fromhex('020000000300000002000000030000000200000003000000'),package=fromhex('e75e019f8d27c7c0')},
 ['WalkingBarrageSmoke']={name='WalkingBarrageSmoke',id=3796132384,code=fromhex('020000000200000004000000010000000200000003000000'),package=fromhex('c6de74973426abe1')},
 ['OrbitalSmoke']={name='OrbitalSmoke',id=3713568312,code=fromhex('02000000020000000300000001000000'),package=fromhex('5a3b3aac74e835bf')},
 ['OrbitalEMSStrike']={name='OrbitalEMSStrike',id=1280711447,code=fromhex('02000000020000000400000003000000'),package=fromhex('d78d56958b956c1e')},
 ['OrbitalLaser']={name='OrbitalLaser',id=970450596,code=fromhex('0200000003000000010000000200000003000000'),package=fromhex('7e7734f8429d2a66')},
 ['OrbitalRailcannon']={name='OrbitalRailcannon',id=2744472229,code=fromhex('0200000001000000030000000300000002000000'),package=fromhex('26305c986123dcf4')},
 ['Autocannon']={name='Autocannon',id=875551083,code=fromhex('030000000400000003000000010000000100000002000000'),package=fromhex('0de819e203558749')},
 ['GrenadeLauncher']={name='GrenadeLauncher',id=3343676429,code=fromhex('0300000004000000010000000400000003000000'),package=fromhex('0000000000000000')},
 ['De-Escalator']={name='De-Escalator',id=153819019,code=fromhex('0300000002000000010000000400000002000000'),package=fromhex('ec4c0b3cc19cee4f')},
 ['BeltFedGrenadeLauncher']={name='BeltFedGrenadeLauncher',id=512147393,code=fromhex('030000000400000001000000040000000100000001000000'),package=fromhex('5b17282461fa4cf2')},
 ['Railgun']={name='Railgun',id=3078242205,code=fromhex('030000000200000003000000010000000400000002000000'),package=fromhex('0000000000000000')},
 ['Speargun']={name='Speargun',id=336693041,code=fromhex('030000000200000003000000040000000100000002000000'),package=fromhex('0000000000000000')},
 ['Recoilless']={name='Recoilless',id=1298599997,code=fromhex('0300000004000000020000000200000004000000'),package=fromhex('516361c34172eb15')},
 ['LaserCannon']={name='LaserCannon',id=2822568285,code=fromhex('0300000004000000030000000100000004000000'),package=fromhex('0000000000000000')},
 ['QuasarCannon']={name='QuasarCannon',id=2625074523,code=fromhex('0300000003000000010000000400000002000000'),package=fromhex('0000000000000000')},
 ['AntiMaterielRifle']={name='AntiMaterielRifle',id=2207713849,code=fromhex('0300000004000000020000000100000003000000'),package=fromhex('0000000000000000')},
 ['ExpendableAntiTank']={name='ExpendableAntiTank',id=3413606544,code=fromhex('0300000003000000040000000100000002000000'),package=fromhex('0000000000000000')},
 ['ExpendableNapalmLauncher']={name='ExpendableNapalmLauncher',id=1813634375,code=fromhex('0300000003000000040000000100000004000000'),package=fromhex('0000000000000000')},
 ['Leveller']={name='Leveller',id=2934950455,code=fromhex('0300000003000000040000000100000003000000'),package=fromhex('875031790c23e8fd')},
 ['Commando']={name='Commando',id=2232989803,code=fromhex('0300000004000000010000000300000002000000'),package=fromhex('0000000000000000')},
 ['Flamethrower']={name='Flamethrower',id=1432571981,code=fromhex('0300000004000000010000000300000001000000'),package=fromhex('0000000000000000')},
 ['HeavyMachineGun']={name='HeavyMachineGun',id=533318241,code=fromhex('0300000004000000010000000300000003000000'),package=fromhex('0000000000000000')},
 ['Machinegun']={name='Machinegun',id=458198946,code=fromhex('0300000004000000030000000100000002000000'),package=fromhex('0000000000000000')},
 ['Stalwart']={name='Stalwart',id=14345846,code=fromhex('030000000400000003000000010000000100000004000000'),package=fromhex('0000000000000000')},
 ['BulletStorm']={name='BulletStorm',id=3288352984,code=fromhex('030000000400000003000000020000000100000004000000'),package=fromhex('4a1419ed2b655fb7')},
 ['AirBurstRocket']={name='AirBurstRocket',id=2007887745,code=fromhex('0300000001000000010000000400000002000000'),package=fromhex('63bcc7c0d7822fe1')},
 ['C4_Backpack']={name='C4_Backpack',id=3748434442,code=fromhex('030000000200000001000000010000000200000001000000'),package=fromhex('1e0cc0a13764a7bb')},
 ['SoloSilo']={name='SoloSilo',id=1337271929,code=fromhex('0300000001000000020000000300000003000000'),package=fromhex('2f069320e4af4729')},
 ['Spear']={name='Spear',id=3923676543,code=fromhex('0300000003000000010000000300000003000000'),package=fromhex('e36c4ba111b60b53')},
 ['WASP']={name='WASP',id=890972990,code=fromhex('0300000003000000010000000300000002000000'),package=fromhex('b7108d989ae99557')},
 ['ArcThrower']={name='ArcThrower',id=992079466,code=fromhex('030000000200000003000000010000000400000004000000'),package=fromhex('ae6e57d0f5b89f2a')},
 ['Sterilizer']={name='Sterilizer',id=4152191751,code=fromhex('0300000004000000010000000300000004000000'),package=fromhex('0000000000000000')},
 ['OneTrueFlag']={name='OneTrueFlag',id=2265180087,code=fromhex('0300000004000000020000000200000001000000'),package=fromhex('ec5290a73f3b0ec4')},
 ['DefoliationTool']={name='DefoliationTool',id=3572024208,code=fromhex('0300000004000000020000000200000003000000'),package=fromhex('400ffe26fdc5ebee')},
 ['BreachingHammer']={name='BreachingHammer',id=3330450692,code=fromhex('0300000004000000020000000400000001000000'),package=fromhex('73c831f1e6d2dd39')},
 ['Epoch']={name='Epoch',id=4261593827,code=fromhex('0300000004000000010000000400000002000000'),package=fromhex('ae669720553bb2a7')},
 ['Maxigun']={name='Maxigun',id=3455841218,code=fromhex('030000000400000002000000030000000100000001000000'),package=fromhex('0a0c7ebab327c6b2')},
 ['Cremator']={name='Cremator',id=2271469939,code=fromhex('030000000300000002000000030000000100000001000000'),package=fromhex('b1c2ed44c6f516df')},
 ['Meltagun']={name='Meltagun',id=774795224,code=fromhex('030000000400000001000000040000000400000003000000'),package=fromhex('7c8446b5792e4fae')},
 ['MachineGunSentry']={name='MachineGunSentry',id=4239785897,code=fromhex('0300000001000000020000000200000001000000'),package=fromhex('7ddf193814d64b15')},
 ['GatlingSentry']={name='GatlingSentry',id=623391597,code=fromhex('03000000010000000200000004000000'),package=fromhex('bf5fde885d322d99')},
 ['TurretMortar']={name='TurretMortar',id=1582497738,code=fromhex('0300000001000000020000000200000003000000'),package=fromhex('8d5b0da4a9995a8c')},
 ['TurretMortarStaticField']={name='TurretMortarStaticField',id=3085503322,code=fromhex('0300000001000000020000000300000002000000'),package=fromhex('215118632b696646')},
 ['TurretMortarGas']={name='TurretMortarGas',id=3183339606,code=fromhex('0300000001000000020000000300000004000000'),package=fromhex('b8096b655dead971')},
 ['TurretRocket']={name='TurretRocket',id=717707279,code=fromhex('0300000001000000020000000200000004000000'),package=fromhex('c55f9ee38cdfbb11')},
 ['TurretAutocannon']={name='TurretAutocannon',id=854563507,code=fromhex('030000000100000002000000010000000400000001000000'),package=fromhex('3da9ba673a63dc54')},
 ['FlameSentry']={name='FlameSentry',id=474724029,code=fromhex('030000000100000002000000030000000100000001000000'),package=fromhex('7d281fad17e97715')},
 ['TurretLaserCannon']={name='TurretLaserCannon',id=960389145,code=fromhex('030000000100000002000000030000000100000002000000'),package=fromhex('79fdc184f63b3136')},
 ['FRV']={name='FRV',id=3935317067,code=fromhex('04000000030000000200000003000000020000000300000001000000'),package=fromhex('434fc17a9f19df0b')},
 ['FRV_Supply']={name='FRV_Supply',id=2636699686,code=fromhex('04000000030000000400000004000000030000000100000002000000'),package=fromhex('ae7c731757689f14')},
 ['FRV_Incinerator']={name='FRV_Incinerator',id=2846457047,code=fromhex('04000000030000000200000004000000030000000100000001000000'),package=fromhex('4d170bbddf40ee2c')},
 ['PatriotExosuit']={name='PatriotExosuit',id=295629711,code=fromhex('04000000030000000200000001000000040000000300000003000000'),package=fromhex('66af8847299a7422')},
 ['EmancipatorExosuit']={name='EmancipatorExosuit',id=1290499887,code=fromhex('04000000030000000200000001000000040000000300000001000000'),package=fromhex('0bdbc3059b3e2de7')},
 ['LumbererExosuit']={name='LumbererExosuit',id=3086305673,code=fromhex('04000000030000000200000001000000020000000400000001000000'),package=fromhex('b2113f83a1d84b0a')},
 ['BreakthroughExosuit']={name='BreakthroughExosuit',id=563851843,code=fromhex('04000000030000000200000004000000020000000300000001000000'),package=fromhex('fcd95275db17e47d')},
 ['ClanStationSEAFSquad']={name='ClanStationSEAFSquad',id=1449420233,code=fromhex('040000000300000002000000020000000300000001000000'),package=fromhex('5c520aa03094b56e')},
 ['BastionTank']={name='BastionTank',id=2002187052,code=fromhex('040000000300000002000000030000000400000003000000010000000300000001000000'),package=fromhex('798149f7e3dceb68')},
}
local anchors={{name='EagleStrafingRun',id=2808191861,code=fromhex('010000000200000002000000'),package=fromhex('14fa92654cbc262c')},{name='EagleAirstrike',id=1238358532,code=fromhex('01000000020000000300000002000000'),package=fromhex('f338ff0016cc331e')},{name='EagleRearm',id=3837064536,code=fromhex('0100000001000000040000000100000002000000'),package=fromhex('0000000000000000')}}
local definitions,edges={},{}
local default_ini=[=[
; Stratagem Extra Pairs v0.5.0 - configurable test
; WAIT 5 MINUTES IN YOUR SHIP WHEN STARTING THE GAME.
; Edit this file with the game CLOSED, save, then restart.
; Each selected Source grants its Extra. Exactly four pair slots.
; Names are case-sensitive. Copy names from the catalogue below.
; To disable a pair, set BOTH its Source and Extra to None.
; No duplicate sources/targets, self-links or chains in this four-pair build.
; Eagles, Rearm, mission utilities, tutorial and reward variants are excluded.

[Links]
Source1=OrbitalPrecisionStrike
Extra1=OrbitalGasStrike
Source2=OrbitalGatlingBarrage
Extra2=OrbitalEMSStrike
Source3=OrbitalAirburstStrike
Extra3=GatlingSentry
Source4=MachineGunSentry
Extra4=FlameSentry

; NAME CATALOGUE
; These are enabled/selectable non-Eagle entries in our 2026-08-12 export.
; This is a data catalogue, NOT proof every entry is released, owned or functional.
; Default eight are gameplay-tested. Other entries require testing.
; Some data-listed entries may be unused, unreleased or unavailable in your build.
; Choose stratagems you own and can normally select. Runtime validation is required.
; No numeric enum IDs needed; the mod resolves them in your running game.

; Backpack
; AmmoBackpack = BACKPACK. SUPPLY BACKPACK
; BallisticShield = BACKPACK. BALLISTIC SHIELD BACKPACK
; Directional_Shield = BACKPACK. DIRECTIONAL ENERGY SHIELD
; ShieldGeneratorPack = BACKPACK.  GENERATOR PACK
; Jumppack = BACKPACK. JUMPPACK BACKPACK
; HoverPack = BACKPACK. HOVERPACK BACKPACK
; DroneMG = BACKPACK. GUARD DOG (Drone)
; Drone_Laser_Rifle = BACKPACK. Laser Rifle (Drone)
; Drone_Gas = BACKPACK. GUARD DOG GAS PROJECTOR (Drone)
; Drone_Flamer = BACKPACK. GUARD DOG FLAMETHROWER (Drone)
; PortableHellbomb = BACKPACK. HELLBOMB
; WarpPack = BACKPACK. DISPLACEMENT BACKPACK
; Drone_Stun_Arc = BACKPACK. GUARD DOG (Drone) Stun

; Emplacements
; GrenadierBattlement = EMPLACEMENTS. DEFENSE WALL GRENADE LAUNCHER
; ShieldGeneratorRelay = EMPLACEMENTS. SHIELD GENERATOR RELAY
; HMG_Emplacement = EMPLACEMENTS. HEAVY MACHINEGUN EMPLACEMENT
; AntiPersonnalMine = EMPLACEMENTS. ANTI-PERSONNEL MINE DEPLOYER
; IncendiaryMines = EMPLACEMENTS. INCENDIARY MINE DEPLOYER
; AntiTankMines = EMPLACEMENTS. ANTI-TANK MINE DEPLOYER
; GasMines = EMPLACEMENTS. GAS MINE DEPLOYER
; TurretTesla = EMPLACEMENTS. TESLA TOWER
; AntiTankEmplacement = EMPLACEMENTS. ANTI TANK EMPLACEMENT

; Orbital
; OrbitalPrecisionStrike = ORBITAL. PRECISION STRIKE
; OrbitalGasStrike = ORBITAL. GAS STRIKE
; OrbitalAirburstStrike = ORBITAL. AIRBURST STRIKE
; OrbitalGatlingBarrage = ORBITAL. GATLING BARRAGE
; Orbital120mmHEBarrage = ORBITAL. 120MM HE STRIKE
; OrbitalNapalmBarrage = ORBITAL. NAPALM BARRAGE
; Orbital380mmHEBarrage = ORBITAL. 380MM HE BARRAGE
; OrbitalWalkingBarrage = ORBITAL. WALKING BARRAGE
; WalkingBarrageSmoke = ORBITAL. WALKING BARRAGE SMOKE
; OrbitalSmoke = ORBITAL. SMOKE STRIKE
; OrbitalEMSStrike = ORBITAL. STATIC FIELD CONDUTORS
; OrbitalLaser = ORBITAL. LASER
; OrbitalRailcannon = ORBITAL. RAILCANNON

; TeamWeapons
; Autocannon = TEAM WEAPONS. AUTOMATIC CANNON
; GrenadeLauncher = TEAM WEAPONS. GRENADE LAUNCHER
; De-Escalator = TEAM WEAPONS. GRENADE LAUNCHER TACTICAL
; BeltFedGrenadeLauncher = TEAM WEAPONS. BELT FED GRENADE LAUNCHER
; Railgun = TEAM WEAPONS. RAILGUN 
; Speargun = TEAM WEAPONS. HARPOON GUN 
; Recoilless = TEAM WEAPONS. RECOILLESS RIFLE
; LaserCannon = TEAM WEAPONS. LASER CANNON
; QuasarCannon = TEAM WEAPONS. LASER PULSE CANNON
; AntiMaterielRifle = TEAM WEAPONS. SNIPER
; ExpendableAntiTank = TEAM WEAPONS. EXPENDABLE ANTI-TANK
; ExpendableNapalmLauncher = TEAM WEAPONS. EXPENDABLE NAPALM LAUNCHER
; Leveller = TEAM WEAPONS. EXPENDABLE MASSIVE ROCKET LAUNCHER
; Commando = TEAM WEAPONS. COMMANDO
; Flamethrower = TEAM WEAPONS. FLAMETHROWER
; HeavyMachineGun = TEAM WEAPONS. HEAVY MACHINEGUN
; Machinegun = TEAM WEAPONS. MACHINEGUN
; Stalwart = TEAM WEAPONS. LIGHT MACHINE GUN
; BulletStorm = TEAM WEAPONS. EXPENDABLE MACHINEGUN
; AirBurstRocket = TEAM WEAPONS. AIR BURST ROCKET LAUNCHER
; C4_Backpack = TEAM WEAPONS. C4
; SoloSilo = TEAM WEAPONS. MINI MISSILE SILO
; Spear = TEAM WEAPONS. SPEAR
; WASP = TEAM WEAPONS. WASP
; ArcThrower = TEAM WEAPONS. ARC THROWER 
; Sterilizer = TEAM WEAPONS. CHEM GUN
; OneTrueFlag = TEAM WEAPONS. MELEE FLAG
; DefoliationTool = TEAM WEAPONS. CHAINSAW GREATSWORD
; BreachingHammer = TEAM WEAPONS. SLEDGE HAMMER
; Epoch = TEAM WEAPONS. PLASMA BLASTER
; Maxigun = TEAM WEAPONS. MINIGUN
; Cremator = TEAM WEAPONS. HEAVY FLAMETHROWER
; Meltagun = TEAM WEAPONS. SHARK ENERGY WEAPON

; Sentrys
; MachineGunSentry = SENTRYS. MACHINEGUN
; GatlingSentry = SENTRYS. GATLING
; TurretMortar = SENTRYS. MORTAR
; TurretMortarStaticField = SENTRYS. MORTAR STATICFIELD
; TurretMortarGas = SENTRYS. MORTAR GAS
; TurretRocket = SENTRYS. ROCKET
; TurretAutocannon = SENTRYS. AUTOCANNON
; FlameSentry = SENTRYS. FLAMETHROWER
; TurretLaserCannon = SENTRIES. LASER CANNON SENTRY

; Vehicles
; FRV = VEHICLES. FAST RECON VEHICLE (FRV)
; FRV_Supply = VEHICLES. FAST RECON VEHICLE (Resupply Auto Turret)
; FRV_Incinerator = VEHICLES. FAST RECON VEHICLE (Ramming Flamethrower)
; PatriotExosuit = VEHICLES. COMBAT WALKER
; EmancipatorExosuit = VEHICLES. COMBAT WALKER OBSIDIAN
; LumbererExosuit = VEHICLES. COMBAT WALKER LUMBERER
; BreakthroughExosuit = VEHICLES. COMBAT WALKER BREACHER
; ClanStationSEAFSquad = SEAF Squad
; BastionTank = VEHICLES. BASTION(tank)
]=]
local function trim(s)return s:match('^%s*(.-)%s*$')end
local function configure(text)
 assert(type(text)=='string' and #text<131072,'settings.ini missing or too large')
 text=text:gsub('^\239\187\191','')
 local values={};local section=nil
 for raw in (text..'\n'):gmatch('(.-)\n')do
  local line=trim((raw:gsub('[;#].*$','')))
  if line~='' then
   if line:sub(1,1)=='[' then assert(line=='[Links]','only [Links] section is supported');section='Links'
   else
    assert(section=='Links','setting outside [Links]')
    local k,v=line:match('^([%w_]+)%s*=%s*(.-)%s*$');assert(k,'invalid settings line: '..line)
    assert(k:match('^Source[1-4]$') or k:match('^Extra[1-4]$'),'unknown setting: '..k)
    assert(not values[k],'duplicate setting: '..k);values[k]=v
   end
  end
 end
 local pairs_list,source_set,target_set={},{},{}
 for i=1,4 do
  local s,t=values['Source'..i],values['Extra'..i]
  assert(s and t,'missing Source/Extra for pair '..i)
  if s=='None' or t=='None' then assert(s=='None' and t=='None','both names must be None to disable pair '..i)
  else
   assert(catalog[s],'unknown or excluded source: '..s);assert(catalog[t],'unknown or excluded extra: '..t)
   assert(s~=t,'self-link in pair '..i);assert(not source_set[s],'duplicate source: '..s);assert(not target_set[t],'duplicate extra: '..t)
   source_set[s]=true;target_set[t]=true;pairs_list[#pairs_list+1]={s,t}
  end
 end
 for s in pairs(source_set)do assert(not target_set[s],'chains/cycles are excluded in this four-pair build: '..s)end
 local defs={};for _,a in ipairs(anchors)do defs[#defs+1]=a end
 local e={};for _,p in ipairs(pairs_list)do
  defs[#defs+1]=catalog[p[1]];defs[#defs+1]=catalog[p[2]];e[#e+1]={#defs-1,#defs}
 end
 definitions,edges=defs,e
 return true
end

local function word(blob,off)
 local a,b,c,d=blob:byte(off+1,off+4);if not d then return nil end
 return a+b*256+c*65536+d*16777216
end
local function u32(n)
 local b={};for i=1,4 do b[i]=string.char(n%256);n=math.floor(n/256) end;return table.concat(b)
end
local function u64(n)return u32(n%4294967296)..u32(math.floor(n/4294967296))end
local function pointer(b,o)
 local lo,hi=word(b,o),word(b,o+4)
 if not hi or hi>=32768 then return nil end
 local n=lo+hi*4294967296
 if n<0x80000000 then return nil end
 return n
end
local function validate(api,address,d)
 local b=api.read(address,400)
 if not b or word(b,4)~=d.id or b:sub(169,176)~=d.package then return nil end
 local t=word(b,0);local p=pointer(b,64)
 if not t or t<1 or t>4096 or not p or word(b,72)~=#d.code/4 then return nil end
 if api.read(p,#d.code)~=d.code then return nil end
 return {name=d.name,address=address,kind=t,code=p,payload=pointer(b,152),bytes=b,link=word(b,200)}
end
local function controller(api,log)
 local t={records=nil,modified=false,broken=false}
 local function writable(a)
  local r=api.query(a)
  return r and r.state==MEM_COMMIT and r.protection==4 and (r.kind==MEM_PRIVATE or r.kind==0x40000) and r.base<=a and r.base+r.size>=a+400
 end
 local function linked(b,n)return b:sub(1,200)..u32(n)..b:sub(205)end
 local targets={};for _,e in ipairs(edges) do targets[e[1]]=e[2] end
 function t.arm(found)
  if t.broken or t.modified then log('REFUSED: restart before scanning again');return false end
  t.records=nil
  local r={}
  for id,d in ipairs(definitions) do
   if not found[id] or #found[id]~=1 then log('REFUSED: need exactly one validated '..d.name..' definition');return false end
   local v=validate(api,found[id][1],d)
   if not v then log('REFUSED: definition changed during scan');return false end
   r[id]=v
   if id~=1 and id~=2 and v.link~=0 then log('REFUSED: expected empty additional link for '..d.name);return false end
  end
  if r[1].link~=r[3].kind or r[2].link~=r[3].kind then log('REFUSED: Eagle links do not match resolved Rearm');return false end
  local kinds={}
  for _,v in ipairs(r)do if kinds[v.kind] then log('REFUSED: duplicate type numbers');return false end;kinds[v.kind]=true end
  for _,e in ipairs(edges)do if not writable(r[e[1]].address) then log('REFUSED: source definition not writable');return false end end
  t.records=r
  for _,e in ipairs(edges)do log(string.format('PAIR: %s -> %s (type %d)',r[e[1]].name,r[e[2]].name,r[e[2]].kind))end
  log('VALIDATED: configured links; applying automatically');return true
 end
 function t.apply(restore)
  if t.broken then log('REFUSED: previous transaction failed; restart game');return false end
  if not t.records then log('REFUSED: validated scan required');return false end
  local r=t.records;local before={};local todo={}
  for id,d in ipairs(definitions) do
   local v=validate(api,r[id].address,d)
   local target=targets[id]
   if not v or (v.bytes~=r[id].bytes and (not target or v.bytes~=linked(r[id].bytes,r[target].kind))) then
    log('REFUSED: unexpected definition change: '..d.name..'; no writes');return false
   end
   if target and not writable(r[id].address) then log('REFUSED: source protection changed');return false end
   before[id]=v.bytes
  end
  for _,e in ipairs(edges) do
   local id=e[1];local desired=restore and 0 or r[e[2]].kind
   if before[id]~=linked(r[id].bytes,desired) then todo[#todo+1]={id=id,desired=desired} end
  end
  if #todo==0 then if restore then t.modified=false end;log(restore and 'UNCHANGED: configured links already restored' or 'UNCHANGED: configured links already applied');return true end
  if restore and not t.modified then log('REFUSED: these links were not applied by this test');return false end
  local attempted={}
  local function fail(reason)
   t.broken=true;t.modified=true
   log('TRANSACTION FAILED: '..reason..'; attempting rollback; restart required')
   for j=#attempted,1,-1 do
    local x=attempted[j];local a=r[x.id].address;local current=api.read(a,400)
    if current==before[x.id] then log('ROLLBACK: '..r[x.id].name..' already unchanged')
    elseif current==linked(r[x.id].bytes,x.desired) and writable(a) then
     local ok=api.write4(a+200,before[x.id]:sub(201,204))
     log('ROLLBACK '..r[x.id].name..': '..((ok and api.read(a,400)==before[x.id]) and 'verified' or 'NOT VERIFIED'))
    else log('ROLLBACK REFUSED: '..r[x.id].name..' changed unexpectedly') end
   end
   return false
  end
  t.modified=true
  for _,x in ipairs(todo) do
   local a=r[x.id].address
   if not writable(a) or api.read(a,400)~=before[x.id] then return fail('record changed before write') end
   attempted[#attempted+1]=x
   local ok=api.write4(a+200,u32(x.desired))
   if not ok or api.read(a,400)~=linked(r[x.id].bytes,x.desired) then return fail('write not verified for '..r[x.id].name) end
   log('VERIFIED: '..r[x.id].name..' additional='..x.desired)
  end
  for _,e in ipairs(edges)do
   local desired=restore and 0 or r[e[2]].kind
   if api.read(r[e[1]].address,400)~=linked(r[e[1]].bytes,desired) then return fail('final configured-link verification failed') end
  end
  t.modified=not restore
  log(restore and 'RESTORED: configured definition links; restart to clear any active mission entries' or 'APPLIED: configured links verified; select original loadout afterward and launch a NEW mission')
  return true
 end
 return t
end

if ...=='link_test_unit' then return {definitions=definitions,validate=validate,u32=u32,u64=u64,controller=controller,configure=configure,catalog=catalog,default_ini=default_ini,get_config=function()return definitions,edges end} end
assert(ffi_ok and ffi and ffi.abi('64bit'),'Windows x64 LuaJIT FFI required')
assert(type(update)=='function','game update unavailable')
local loader=rawget(_G,'CowboyBingusModLoader')
assert(type(loader)=='table' and type(loader.api)=='number' and loader.api>=1,'Bingus Shared Loader API 1 required')
local api=build_api()
local root=assert(os.getenv('LOCALAPPDATA'),'LOCALAPPDATA missing')
for _,p in ipairs({'CowboyBingus','Helldivers2','StratagemExtraPairs'}) do root=root..'/'..p;assert(api.mkdir(root)) end
local config_path=root..'/settings.ini'
root=root..'/'..os.date('%Y%m%d-%H%M%S');assert(api.mkdir(root))
local state={started_at=api.now_ms(),attempted=false,finished=false,applied=false}
_G.StratagemExtraPairs=state
local function log(message)
 local text=os.date('%H:%M:%S')..' '..message..'\n'
 local f=assert(io.open(root..'/LOG.txt','ab'));assert(f:write(text));f:close()
 f=assert(io.open(root..'/STATUS.txt','wb'));assert(f:write(text));f:close()
 print('[StratagemExtraPairs] '..message)
end
local file=io.open(config_path,'rb')
local text
if file then text=file:read('*a');file:close()
else
 text=default_ini
 local out=assert(io.open(config_path,'wb'),'cannot create settings.ini');assert(out:write(text));out:close()
end
local ok,err=pcall(configure,text)
if not ok then log('CONFIG ERROR: '..tostring(err)..'; no scan or writes; fix settings.ini and restart');state.finished=true;return end
if #edges==0 then log('DISABLED: all pairs are None');state.finished=true;return end
for _,e in ipairs(edges) do log('CONFIG PAIR: '..definitions[e[1]].name..' -> '..definitions[e[2]].name) end
local control=controller(api,log)
local needles={}
for _,d in ipairs(definitions) do
 local p=u32(d.id);needles[#needles+1]=p
 local a=api.address_of(p)
 if not a or a>=0x80000000 then log('UNSUPPORTED: low Lua heap separation unavailable');return end
 api.add_needle(p)
end
local function start()
 state.scan={cursor=0x80000000,regions=0,read=0,failed=0,seen={},found={},reported=0}
 log('SCANNING: remain aboard ship; automatic application follows successful validation')
end
local function finish(complete)
 local s=state.scan;state.scan=nil;state.finished=true
 log(string.format('SCAN %s: %.0f bytes read; %.0f failed bytes',complete and 'DONE' or 'INCOMPLETE',s.read,s.failed))
 if not complete or s.failed>0 then log('REFUSED: scan incomplete; no automatic retry; send LOG.txt');return end
 if control.arm(s.found) then
  state.applied=control.apply(false)
  if state.applied then log('APPLIED: CONFIGURED LINKS VERIFIED - startup complete; select your loadout and launch') end
 end
end
local function tick_scan()
 local s=state.scan;local deadline=os.clock()+0.0015
 while os.clock()<deadline do
  if not s.current then
   if s.cursor>=0x7FFFFFFF0000 then finish(true);return end
   if s.regions>=200000 then finish(false);return end
   local r=api.query(s.cursor)
   if not r then finish(s.cursor>=0x7FFF00000000);return end
   local last=r.base+r.size
   if last<=s.cursor then finish(false);return end
   local first=math.max(s.cursor,r.base);s.cursor=last;s.regions=s.regions+1
   if r.state==MEM_COMMIT and (r.protection==2 or r.protection==4) and (r.kind==MEM_PRIVATE or r.kind==0x40000) then s.current={address=first,remaining=last-first} end
  else
   local c=s.current;local n=math.min(CHUNK,c.remaining);local hits={}
   local ok=api.scan(c.address,n,function(a,id)hits[#hits+1]={a,id}end)
   if ok then s.read=s.read+n else s.failed=s.failed+n end
   for _,h in ipairs(hits) do
    local a,id=h[1],h[2]
    if a%4==0 and not s.seen[a] then
     s.seen[a]=true;local v=validate(api,a-4,definitions[id])
     if v then
      s.found[id]=s.found[id] or {};s.found[id][#s.found[id]+1]=a-4
      log(string.format('DEFINITION: %s at %X, type=%d, additional=%d',v.name,v.address,v.kind,v.link))
     end
    end
   end
   if n==c.remaining then s.current=nil else c.address=c.address+n-3;c.remaining=c.remaining-n+3 end
  end
 end
 if os.time()-s.reported>=5 then s.reported=os.time();log(string.format('SCANNING: %.0f MiB',s.read/1048576)) end
end
local function tick()
 if not state.attempted and api.now_ms()-state.started_at>=60000 then
  state.attempted=true
  start()
 end
 if state.scan then tick_scan() end
end
local previous=update
local unpack_values=unpack or table.unpack
local function pack(...)return {n=select('#',...),...}end
local fatal=false
local function after(...)
 local r=pack(...);local ok,err=pcall(tick)
 if not ok then fatal=true;state.scan=nil;pcall(log,'FAILED: '..tostring(err)..'; restart game to reset edits') end
 return unpack_values(r,1,r.n)
end
update=function(...)if fatal or state.finished then return previous(...) end;return after(previous(...)) end
log('WAITING v0.5.0: automatic scan in 60 seconds; WAIT 5 MINUTES IN YOUR SHIP WHEN STARTING THE GAME. No hotkeys required.')
