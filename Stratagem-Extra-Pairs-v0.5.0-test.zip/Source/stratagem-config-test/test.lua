local m=assert(loadfile('stratagem-config-test/main.lua'))('link_test_unit')
assert(m.configure(m.default_ini));m.definitions,m.edges=m.get_config()
local fixture=assert(loadfile('stratagem-config-test/fixture.lua'))()
local addresses={}
local mem={};local originals={}
local function reset()for a,h in pairs(fixture)do mem[a]=(h:gsub('..',function(v)return string.char(tonumber(v,16))end));originals[a]=mem[a]end end
reset()
for id,d in ipairs(m.definitions)do for a,b in pairs(mem)do if #b==400 and b:sub(5,8)==m.u32(d.id)then addresses[id]=a end end;assert(addresses[id])end
local found={};for i,a in ipairs(addresses)do found[i]={a}end
local writes=0;local rw=true;local fail_on=nil
local api={read=function(a,n)local b=mem[a];return b and #b==n and b or nil end,
 query=function(a)return {base=a,size=400,state=0x1000,protection=rw and 4 or 2,kind=0x20000}end,
 write4=function(a,b)
  writes=writes+1;if writes==fail_on then return false end
  local old=assert(mem[a-200]);assert(#old==400 and #b==4)
  mem[a-200]=old:sub(1,200)..b..old:sub(205);return true
 end}
local function new()reset();writes=0;rw=true;fail_on=nil;return m.controller(api,function()end)end
local t=new();assert(not t.apply(false));assert(t.arm(found));assert(t.apply(false) and writes==4)
for _,e in ipairs(m.edges)do assert(m.validate(api,addresses[e[1]],m.definitions[e[1]]).link==t.records[e[2]].kind)end
assert(t.apply(false) and writes==4)
assert(t.apply(true) and writes==8 and not t.modified)
for a,b in pairs(originals)do assert(mem[a]==b)end
-- Every possible failed write must roll back completed writes and lock further actions.
for index=1,4 do
 t=new();assert(t.arm(found));fail_on=index
 assert(not t.apply(false) and t.broken)
 for a,b in pairs(originals)do assert(mem[a]==b,'rollback mismatch')end
 local n=writes;assert(not t.apply(false) and not t.apply(true) and writes==n)
end
t=new();found[4][2]=addresses[4];assert(not t.arm(found));found[4][2]=nil
assert(t.arm(found));rw=false;assert(not t.apply(false) and writes==0)
t=new();assert(t.arm(found));local a=addresses[9];mem[a]=mem[a]:sub(1,80)..'X'..mem[a]:sub(82)
assert(not t.apply(false) and writes==0)
t=new();assert(t.arm(found));assert(t.apply(false));fail_on=6
assert(not t.apply(true) and t.broken)
for _,e in ipairs(m.edges)do assert(m.validate(api,addresses[e[1]],m.definitions[e[1]]).link==t.records[e[2]].kind)end
print('PASS: configured default definitions, four exact edits/restores, all apply failure positions roll back, restore rollback, failed-state lock, ambiguity/protection/anchor guards')
