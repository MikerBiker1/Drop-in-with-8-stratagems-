local function read(p)local f=assert(io.open(p,'rb'));local s=f:read('*a');f:close();return s end
local source=read('stratagem-config-test/main.lua')
local m=assert(load(source,'pure','t',_G))('link_test_unit')
assert(m.configure(m.default_ini));m.definitions,m.edges=m.get_config()
local function run(mode)
local configtext=m.default_ini
local existing=mode=='custom'
local types={30,18,49,118,41,4,34,83,66,121,8}
if existing then configtext=configtext:gsub('Extra4=FlameSentry','Extra4=AntiMaterielRifle');types[11]=777 end
assert(m.configure(configtext));m.definitions,m.edges=m.get_config()
local base=0x100000000;local blob=string.rep('\0',16384)
local function put(o,v)blob=blob:sub(1,o)..v..blob:sub(o+#v+1)end
for i,d in ipairs(m.definitions) do
 local off=(i-1)*512;local code=base+off+256
 put(off,m.u32(types[i]));put(off+4,m.u32(d.id));put(off+64,m.u64(code));put(off+72,m.u32(#d.code/4));put(off+168,d.package);put(off+256,d.code);if i==1 or i==2 then put(off+200,m.u32(49)) end
 put(8192+i*64,m.u64(base+off))
end
local clock,keys,files,needles=0,{}, {},{}
local now,write_count,wall_offset=0,0,0
local queries=0
local api={now_ms=function()return now end,c_search=true,mkdir=function()return true end,address_of=function()return 0x100000 end,
 clear_needles=function()needles={}end,add_needle=function(p)needles[#needles+1]=p end,
 longest_needle=function()local n=0;for _,v in ipairs(needles)do n=math.max(n,#v)end;return n end,
 query=function(a)
  queries=queries+1
  if a<base then return {base=0x80000000,size=base-0x80000000,state=0,kind=0,protection=0}
  elseif a<base+#blob then return {base=base,size=#blob,state=0x1000,kind=0x20000,protection=4}
  elseif a<0x7FFFFFFF0000 then return {base=base+#blob,size=0x7FFFFFFF0000-base-#blob,state=0,kind=0,protection=0}end
 end,
 read=function(a,n)if a<base or a+n>base+#blob then return nil end;return blob:sub(a-base+1,a-base+n)end,
 scan=function(a,n,cb)if mode=='read_failure' then return false end;local b=blob:sub(a-base+1,a-base+n);for id,p in ipairs(needles)do local pos=1;while true do local x=b:find(p,pos,true);if not x then break end;cb(a+x-1,id);pos=x+1 end end;return true end}
api.write4=function(a,b)write_count=write_count+1;assert(#b==4);put(a-base,b);return true end
local ffi={abi=function()return true end,cdef=function()end,load=function()return {GetAsyncKeyState=function(k)return keys[k] and -32768 or 0 end}end,cast=function(_,v)return v end}
local env=setmetatable({TEST_API=api,require=function()return ffi end,print=function()end,CowboyBingusModLoader={api=1,version=18},update=function()return 42,nil,'tail' end,
 os={clock=function()clock=clock+0.001;return clock end,time=function()return 1000+wall_offset+math.floor(clock)end,date=function()return 'test' end,getenv=function()return '/test' end},
 io={open=function(path,mode)if mode=='rb' then if existing then return {read=function()return configtext end,close=function()end}end;return nil end;local s='';return {write=function(_,v)s=s..v;return true end,close=function()files[path]=s;return true end}end}},{__index=_G});env._G=env
if mode=='missing' then put(10*512+4,m.u32(0)) end
assert(load(source:gsub('local api=build_api%(%)','local api=TEST_API'),'runtime','t',env))()
local function ticks(n)for i=1,n do local a,b,c=env.update();assert(a==42 and b==nil and c=='tail')end end
ticks(300);assert(queries==0 and write_count==0)
wall_offset=86400;now=59999;ticks(300);assert(queries==0 and write_count==0,'must wait full monotonic 60 seconds')
wall_offset=-86400;now=60000;ticks(3000)
local state=env.StratagemExtraPairs
assert(state.attempted and state.finished and not state.scan)
if mode=='success' or mode=='custom' then
 assert(state.applied and write_count==4)
 for _,e in ipairs(m.edges)do
  local source=(e[1]-1)*512
  local target=types[e[2]]
  assert(blob:sub(source+201,source+204)==m.u32(target))
 end
 local good=false;for p,c in pairs(files)do if p:find('STATUS.txt',1,true) and c:find('APPLIED: CONFIGURED LINKS VERIFIED',1,true)then good=true end end;assert(good)
else assert(not state.applied and write_count==0) end
local cfg_written=false;for p,c in pairs(files)do if p:find('/settings.ini',1,true)then cfg_written=true;assert(c==m.default_ini)end end;assert(cfg_written~=existing)
local q,w=queries,write_count;now=3600000;ticks(3000)
assert(queries==q and write_count==w,'no retries, polling or reapplication after completion')
end
for _,mode in ipairs({'success','custom','missing','read_failure'})do run(mode)end
print('PASS: exact 60-second delay, system-clock jumps ignored, automatic scan/apply, custom AMR pair, config creation/preservation, all four edits, failure blocks writes, no repeat scans, callback returns')
